SGM — Stay Getting Money website
================================

FILES
- index.html: the complete responsive website. CSS and JavaScript are included in this one file.

BEFORE YOU PUBLISH
1. Open index.html in a text editor.
2. Find this line near the bottom:
   const SGM_INSTAGRAM_USERNAME = "YOUR_INSTAGRAM_USERNAME";
3. Replace YOUR_INSTAGRAM_USERNAME with your actual Instagram handle, without the @.
   Example: const SGM_INSTAGRAM_USERNAME = "sgmstreetwear";
4. Replace the sample product names/descriptions and “Ask for price” with your actual items and prices.
5. The product artwork is a graphic mockup, not a photo of actual inventory. For a more authentic store, replace each product-art block with your real product photos.

FREE PUBLISHING OPTION: GITHUB PAGES
1. Create/sign in to a GitHub account at https://github.com/
2. Create a new public repository, for example: sgm-clothing-site
3. Upload index.html to the root of the repository (the main page).
4. In the repository, open Settings → Pages.
5. Under the build/deployment settings, choose “Deploy from a branch”, select the main branch and /(root), then Save.
6. Wait for the published link shown in the Pages section. It usually looks like:
   https://YOUR-GITHUB-USERNAME.github.io/sgm-clothing-site/
7. Open that link on your phone and test all links.

No monthly website hosting fee is required for this static site on GitHub Pages. You do not need to add a payment processor. A custom domain is optional and usually costs money.

IMPORTANT
- The website does not take online payments. Customers browse the sample collection and contact you through Instagram.
- The default links point to Instagram's general website until you add your handle.
- GitHub's interface can change; use GitHub Pages documentation if the menu labels differ:
  https://docs.github.com/en/pages
